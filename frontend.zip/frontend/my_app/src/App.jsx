import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Login from "./components/Login/Login";
import Otp_verify from "./components/Login/Otp_verify";
import Main from "./components/Dashboard/Main";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/otp-verify" element={<Otp_verify />} />
        <Route path="/dashboard" element={<Main/>}/>
      </Routes>
    </Router>
  );
}

export default App;
