import React from "react";
import "./Fooder.css";

const Fooder = () => {
  return (
    <footer className="footer">
      <p>© 2025 Fresh Milk Delivery | All Rights Reserved</p>
      <p>Contact: support@freshmilk.com</p>
    </footer>
  );
};

export default Fooder;
